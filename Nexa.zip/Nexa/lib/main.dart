import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models.dart';

void main() {
  runApp(const NexaApp());
}

class NexaApp extends StatelessWidget {
  const NexaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nexa',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: const Color(0xFF1565C0),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          filled: true,
          fillColor: Colors.grey[50],
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF1565C0), width: 2),
          ),
        ),
      ),
      home: const LoginScreen(),
    );
  }
}

// --- TELA DE LOGIN ---
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usuarioController = TextEditingController();
  final _senhaController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  void _fazerLogin() {
    if (_formKey.currentState!.validate()) {
      Usuario? usuarioEncontrado;
      try {
        usuarioEncontrado = BancoDeDados.usuarios.firstWhere(
                (u) => u.nome == _usuarioController.text && u.senha == _senhaController.text
        );
      } catch (e) {
        usuarioEncontrado = null;
      }

      if (usuarioEncontrado != null) {
        BancoDeDados.usuarioLogado = usuarioEncontrado;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen(nomeUsuario: usuarioEncontrado!.nome)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Usuário ou senha incorretos'), backgroundColor: Colors.redAccent),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                const Icon(Icons.layers, size: 100, color: Color(0xFF1565C0)),
                const SizedBox(height: 20),
                const Text('NEXA', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF1565C0), letterSpacing: 2.0)),
                const SizedBox(height: 48),
                TextFormField(
                  controller: _usuarioController,
                  decoration: const InputDecoration(labelText: 'Usuário', prefixIcon: Icon(Icons.person, color: Color(0xFF1565C0))),
                  validator: (v) => v!.isEmpty ? 'Digite o usuário' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _senhaController,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(labelText: 'Senha', prefixIcon: Icon(Icons.lock, color: Color(0xFF1565C0)), counterText: ""),
                  validator: (v) => v!.length < 6 ? 'Senha deve ter 6 dígitos' : null,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _fazerLogin,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1565C0),
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('ENTRAR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 24),
                TextButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const RegisterScreen()));
                  },
                  child: const Text("Criar conta", style: TextStyle(color: Color(0xFF1565C0), fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// --- TELA DE CADASTRO DE USUÁRIO ---
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nomeController = TextEditingController();
  final _senhaController = TextEditingController();
  final _confirmaController = TextEditingController();
  String _nivelSelecionado = 'Usuário';

  void _cadastrar() {
    if (_formKey.currentState!.validate()) {
      if (_senhaController.text != _confirmaController.text) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('As senhas não coincidem!'), backgroundColor: Colors.redAccent));
        return;
      }
      BancoDeDados.adicionarUsuario(_nomeController.text, _senhaController.text, _nivelSelecionado);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cadastro realizado! Faça login.'), backgroundColor: Colors.green));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Novo Cadastro"), backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nomeController,
                decoration: const InputDecoration(labelText: 'Usuário', prefixIcon: Icon(Icons.person_add)),
                validator: (v) => v!.isEmpty ? 'Informe um usuário' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _nivelSelecionado,
                decoration: const InputDecoration(labelText: 'Nível', prefixIcon: Icon(Icons.admin_panel_settings)),
                items: ['Usuário', 'Moderador'].map((n) => DropdownMenuItem(value: n, child: Text(n))).toList(),
                onChanged: (v) => setState(() => _nivelSelecionado = v!),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _senhaController,
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 6,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(labelText: 'Senha (6 dígitos)', prefixIcon: Icon(Icons.lock), counterText: ""),
                validator: (v) => v!.length < 6 ? 'Mínimo 6 dígitos' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _confirmaController,
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 6,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(labelText: 'Repetir Senha', prefixIcon: Icon(Icons.lock_reset), counterText: ""),
                validator: (v) => v!.isEmpty ? 'Confirme a senha' : null,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _cadastrar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('CADASTRAR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- TELA INICIAL (HOME) ---
class HomeScreen extends StatefulWidget {
  final String nomeUsuario;
  const HomeScreen({super.key, required this.nomeUsuario});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _numeroMesa = "";

  void _adicionarDigito(String digito) {
    setState(() {
      if (_numeroMesa.length < 6) {
        _numeroMesa += digito;
      }
    });
  }

  void _limpar() {
    setState(() {
      _numeroMesa = "";
    });
  }

  void _confirmar() {
    if (_numeroMesa.isEmpty) return;

    int numero = int.parse(_numeroMesa);
    Comanda comandaSelecionada = BancoDeDados.pegarOuAbrirComanda(numero);
    _limpar();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PedidoScreen(comanda: comandaSelecionada),
      ),
    );
  }

  Widget _botaoTeclado(String label, VoidCallback onPressed, {Color? corFundo, Color? corTexto}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: corFundo ?? Colors.grey[100],
            foregroundColor: corTexto ?? const Color(0xFF1565C0),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 2,
          ),
          child: Text(
            label,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: corTexto),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Abrir Mesa/Comanda"),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        actions: [
          Center(child: Text("Olá, ${widget.nomeUsuario}  ", style: const TextStyle(fontWeight: FontWeight.bold))),
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
            },
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 2,
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "DIGITE O NÚMERO DA MESA",
                    style: TextStyle(color: Colors.grey, letterSpacing: 1.5, fontSize: 14),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _numeroMesa.isEmpty ? "___" : _numeroMesa,
                    style: TextStyle(
                      fontSize: 80,
                      fontWeight: FontWeight.bold,
                      color: _numeroMesa.isEmpty ? Colors.grey[300] : const Color(0xFF1565C0),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              padding: const EdgeInsets.all(16),
              color: Colors.grey[50],
              child: Column(
                children: [
                  Expanded(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [_botaoTeclado("7", () => _adicionarDigito("7")), _botaoTeclado("8", () => _adicionarDigito("8")), _botaoTeclado("9", () => _adicionarDigito("9"))])),
                  Expanded(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [_botaoTeclado("4", () => _adicionarDigito("4")), _botaoTeclado("5", () => _adicionarDigito("5")), _botaoTeclado("6", () => _adicionarDigito("6"))])),
                  Expanded(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [_botaoTeclado("1", () => _adicionarDigito("1")), _botaoTeclado("2", () => _adicionarDigito("2")), _botaoTeclado("3", () => _adicionarDigito("3"))])),
                  Expanded(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [_botaoTeclado("C", _limpar, corFundo: Colors.red[100], corTexto: Colors.red), _botaoTeclado("0", () => _adicionarDigito("0")), _botaoTeclado("OK", _confirmar, corFundo: const Color(0xFF1565C0), corTexto: Colors.white)])),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        color: Colors.white,
        child: Container(
          height: 60,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(icon: const Icon(Icons.home, color: Color(0xFF1565C0)), onPressed: () {}),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const CategoriesScreen()));
                },
                icon: const Icon(Icons.list_alt),
                label: const Text("Produtos"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                ),
              ),
              IconButton(icon: const Icon(Icons.settings, color: Colors.grey), onPressed: () {}),
            ],
          ),
        ),
      ),
    );
  }
}

// --- TELA 1: LISTA DE CATEGORIAS (COM PERMISSÃO DE MODERADOR) ---
class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  bool get _eModerador => BancoDeDados.usuarioLogado?.nivel == 'Moderador';

  void _mostrarDialogCategoria({int? index}) {
    final controller = TextEditingController();
    if (index != null) {
      controller.text = BancoDeDados.categorias[index].nome;
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(index == null ? "Nova Categoria" : "Editar Categoria"),
        content: TextField(
          controller: controller,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: "Nome da Categoria"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancelar")),
          ElevatedButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                setState(() {
                  if (index == null) {
                    BancoDeDados.adicionarCategoria(controller.text.toUpperCase());
                  } else {
                    BancoDeDados.editarCategoria(index, controller.text.toUpperCase());
                  }
                });
                Navigator.pop(ctx);
              }
            },
            child: const Text("Salvar"),
          ),
        ],
      ),
    );
  }

  void _confirmarExclusao(int index) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Excluir Categoria"),
        content: Text("Deseja apagar '${BancoDeDados.categorias[index].nome}' e todos os seus produtos?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancelar")),
          TextButton(
            onPressed: () {
              setState(() {
                BancoDeDados.removerCategoria(index);
              });
              Navigator.pop(ctx);
            },
            child: const Text("Excluir", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Categorias"),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
      ),
      body: BancoDeDados.categorias.isEmpty
          ? const Center(child: Text("Nenhuma categoria cadastrada."))
          : ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: BancoDeDados.categorias.length,
        separatorBuilder: (_, __) => const Divider(),
        itemBuilder: (context, index) {
          final categoria = BancoDeDados.categorias[index];
          return ListTile(
            contentPadding: const EdgeInsets.all(8),
            leading: CircleAvatar(
              backgroundColor: const Color(0xFF1565C0),
              child: Text(
                categoria.nome.isNotEmpty ? categoria.nome[0] : "?",
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(categoria.nome, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            subtitle: Text("${categoria.produtos.length} produtos"),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_eModerador) ...[
                  IconButton(
                    icon: const Icon(Icons.edit, color: Colors.orange),
                    onPressed: () => _mostrarDialogCategoria(index: index),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _confirmarExclusao(index),
                  ),
                ],
                const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
              ],
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductsByCategoryScreen(categoryIndex: index),
                ),
              ).then((_) => setState((){}));
            },
          );
        },
      ),
      floatingActionButton: _eModerador
          ? FloatingActionButton.extended(
        onPressed: () => _mostrarDialogCategoria(),
        backgroundColor: const Color(0xFF1565C0),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text("NOVA CATEGORIA", style: TextStyle(color: Colors.white)),
      )
          : null,
    );
  }
}

// --- TELA 2: LISTA DE PRODUTOS DA CATEGORIA (COM PERMISSÃO DE MODERADOR) ---
class ProductsByCategoryScreen extends StatefulWidget {
  final int categoryIndex;
  const ProductsByCategoryScreen({super.key, required this.categoryIndex});

  @override
  State<ProductsByCategoryScreen> createState() => _ProductsByCategoryScreenState();
}

class _ProductsByCategoryScreenState extends State<ProductsByCategoryScreen> {
  bool get _eModerador => BancoDeDados.usuarioLogado?.nivel == 'Moderador';

  void _confirmarExclusao(int prodIndex) {
    final cat = BancoDeDados.categorias[widget.categoryIndex];
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Excluir Produto"),
        content: Text("Apagar '${cat.produtos[prodIndex].nome}'?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancelar")),
          TextButton(
            onPressed: () {
              setState(() {
                BancoDeDados.removerProduto(widget.categoryIndex, prodIndex);
              });
              Navigator.pop(ctx);
            },
            child: const Text("Excluir", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _navegarParaFormulario({int? prodIndex}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProductScreen(
          categoryIndex: widget.categoryIndex,
          itemIndex: prodIndex,
        ),
      ),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final categoria = BancoDeDados.categorias[widget.categoryIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(categoria.nome),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
      ),
      body: categoria.produtos.isEmpty
          ? const Center(child: Text("Nenhum produto nesta categoria."))
          : ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: categoria.produtos.length,
        separatorBuilder: (_, __) => const Divider(),
        itemBuilder: (context, index) {
          final produto = categoria.produtos[index];
          return ListTile(
            leading: const Icon(Icons.fastfood, color: Color(0xFF1565C0)),
            title: Text(produto.nome, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text("R\$ ${produto.preco.toStringAsFixed(2)}"),
            trailing: _eModerador
                ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.orange),
                  onPressed: () => _navegarParaFormulario(prodIndex: index),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _confirmarExclusao(index),
                ),
              ],
            )
                : null,
          );
        },
      ),
      floatingActionButton: _eModerador
          ? FloatingActionButton(
        onPressed: () => _navegarParaFormulario(),
        backgroundColor: const Color(0xFF1565C0),
        child: const Icon(Icons.add, color: Colors.white),
      )
          : null,
    );
  }
}

// --- TELA 3: CADASTRO DE PRODUTO (FORMULÁRIO)
class ProductScreen extends StatefulWidget {
  final int categoryIndex;
  final int? itemIndex;

  const ProductScreen({super.key, required this.categoryIndex, this.itemIndex});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nomeController = TextEditingController();
  final _valorController = TextEditingController();
  final _descController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.itemIndex != null) {
      final produto = BancoDeDados.categorias[widget.categoryIndex].produtos[widget.itemIndex!];
      _nomeController.text = produto.nome;
      _valorController.text = produto.preco.toStringAsFixed(2);
      _descController.text = produto.descricao;
    }
  }

  void _salvarProduto() {
    if (_formKey.currentState!.validate()) {
      double valor = double.parse(_valorController.text.replaceAll(',', '.'));
      String nomeMaiusculo = _nomeController.text.toUpperCase();

      if (widget.itemIndex != null) {
        // EDIÇÃO
        BancoDeDados.editarProduto(
            widget.categoryIndex,
            widget.itemIndex!,
            nomeMaiusculo,
            valor,
            _descController.text
        );
      } else {
        // NOVO
        BancoDeDados.adicionarProduto(
            widget.categoryIndex,
            nomeMaiusculo,
            valor,
            _descController.text
        );
      }

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Salvo!'), backgroundColor: Colors.green));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.itemIndex != null ? "Editar Produto" : "Novo Produto"),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nomeController,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'Nome', prefixIcon: Icon(Icons.fastfood)),
                validator: (v) => v!.isEmpty ? 'Obrigatório' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _valorController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Valor (R\$)', prefixIcon: Icon(Icons.attach_money)),
                validator: (v) => v!.isEmpty ? 'Obrigatório' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descController,
                decoration: const InputDecoration(labelText: 'Descrição', prefixIcon: Icon(Icons.description)),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _salvarProduto,
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1565C0),
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
                ),
                child: const Text('SALVAR', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- TELA DE DETALHES DO PEDIDO ---
class PedidoScreen extends StatefulWidget {
  final Comanda comanda;

  const PedidoScreen({super.key, required this.comanda});

  @override
  State<PedidoScreen> createState() => _PedidoScreenState();
}

class _PedidoScreenState extends State<PedidoScreen> {
  int _categoriaSelecionadaIndex = 0;

  void _adicionarProdutoNaComanda(Produto produto) {
    setState(() {
      try {
        var itemExistente = widget.comanda.itens.firstWhere(
                (item) => item.produto.nome == produto.nome && item.lancado == false
        );
        itemExistente.quantidade++;
      } catch (e) {
        widget.comanda.itens.add(ItemComanda(produto: produto, lancado: false));
      }
    });
  }

  void _lancarPedidos() {
    bool temNovos = widget.comanda.itens.any((item) => item.lancado == false);

    if (!temNovos) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Nenhum item novo para lançar.")));
      return;
    }

    setState(() {
      for (var item in widget.comanda.itens) {
        item.lancado = true;
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Pedido enviado para a cozinha!"), backgroundColor: Colors.green));
    Navigator.pop(context);
  }

  void _removerItem(int index) {
    if (widget.comanda.itens[index].lancado) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Item já enviado. Cancele com o gerente.")));
      return;
    }
    setState(() {
      widget.comanda.itens.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (BancoDeDados.categorias.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text("Erro"), backgroundColor: Colors.red),
        body: const Center(child: Text("Cadastre categorias primeiro!")),
      );
    }

    final categoriaAtual = BancoDeDados.categorias[_categoriaSelecionadaIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text("Mesa ${widget.comanda.numeroMesa}"),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Center(
              child: Text(
                "R\$ ${widget.comanda.totalComanda.toStringAsFixed(2)}",
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          )
        ],
      ),
      body: Column(
        children: [
          // --- PARTE 1: LISTA DE ITENS (Topo) ---
          Expanded(
            flex: 5,
            child: Container(
              color: Colors.white,
              child: widget.comanda.itens.isEmpty
                  ? const Center(
                child: Text(
                  "Comanda Vazia",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 16),
                ),
              )
                  : ListView.separated(
                padding: const EdgeInsets.all(8),
                itemCount: widget.comanda.itens.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final item = widget.comanda.itens[index];
                  return ListTile(
                    dense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                    tileColor: item.lancado ? Colors.grey[100] : Colors.blue[50],
                    leading: CircleAvatar(
                      backgroundColor: item.lancado ? Colors.grey : const Color(0xFF1565C0),
                      radius: 14,
                      child: Text("${item.quantidade}", style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                    title: Text(item.produto.nome, style: TextStyle(fontWeight: FontWeight.bold, color: item.lancado ? Colors.grey[700] : Colors.black)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text("R\$ ${item.total.toStringAsFixed(2)}", style: const TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(width: 8),
                        item.lancado
                            ? const Icon(Icons.check_circle, color: Colors.green, size: 20)
                            : IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                          onPressed: () => _removerItem(index),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),

          // --- PARTE 2: CATEGORIAS (Meio - QUADRADOS GRANDES) ---
          Container(
            height: 110,
            color: Colors.grey[200],
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              itemCount: BancoDeDados.categorias.length,
              itemBuilder: (context, index) {
                final cat = BancoDeDados.categorias[index];
                final isSelected = index == _categoriaSelecionadaIndex;

                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _categoriaSelecionadaIndex = index;
                    });
                  },
                  child: Container(
                    width: 100,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? const Color(0xFF1565C0) : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        if (!isSelected)
                          BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4, offset: const Offset(0, 2))
                      ],
                      border: isSelected ? null : Border.all(color: Colors.grey.shade300),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                        Icon(
                          Icons.restaurant_menu,
                          color: isSelected ? Colors.white : const Color(0xFF1565C0),
                          size: 32,
                        ),
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: Text(
                            cat.nome,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: isSelected ? Colors.white : Colors.black87,
                              fontWeight: FontWeight.bold,
                              fontSize: 13, // Fonte legível
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // --- PARTE 3: PRODUTOS DA CATEGORIA (Baixo - Grid) ---
          Expanded(
            flex: 4,
            child: Container(
              color: Colors.grey[100],
              child: GridView.builder(
                padding: const EdgeInsets.all(8),
                scrollDirection: Axis.horizontal,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, //
                  childAspectRatio: 0.7,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                ),
                itemCount: categoriaAtual.produtos.length,
                itemBuilder: (context, index) {
                  final produto = categoriaAtual.produtos[index];
                  return InkWell(
                    onTap: () => _adicionarProdutoNaComanda(produto),
                    child: Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.fastfood, size: 24, color: Color(0xFF1565C0)),
                          const SizedBox(height: 4),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: Text(
                              produto.nome,
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                            ),
                          ),
                          Text("R\$ ${produto.preco.toStringAsFixed(2)}", style: TextStyle(color: Colors.grey[700], fontSize: 11)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton.extended(
        onPressed: _lancarPedidos,
        backgroundColor: Colors.green,
        icon: const Icon(Icons.check, color: Colors.white),
        label: const Text("LANÇAR", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
}