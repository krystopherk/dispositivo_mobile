// --- MODELO: USUÁRIO ---
class Usuario {
  final String nome;
  final String senha;
  final String nivel;

  Usuario({required this.nome, required this.senha, required this.nivel});
}

// --- MODELO: PRODUTO ---
class Produto {
  String nome;
  double preco;
  String descricao;

  Produto({
    required this.nome,
    required this.preco,
    this.descricao = ''
  });
}

// --- MODELO: CATEGORIA ---
class Categoria {
  String nome;
  List<Produto> produtos;

  Categoria({required this.nome, List<Produto>? produtos})
      : produtos = produtos ?? [];
}

class ItemComanda {
  final Produto produto;
  int quantidade;
  bool lancado;

  ItemComanda({
    required this.produto,
    this.quantidade = 1,
    this.lancado = false,
  });

  double get total => produto.preco * quantidade;
}

// --- MODELO: COMANDA ---
class Comanda {
  final int numeroMesa;
  String status;
  final List<ItemComanda> itens;

  Comanda({
    required this.numeroMesa,
    this.status = 'Aberta',
    List<ItemComanda>? itens,
  }) : itens = itens ?? [];

  double get totalComanda {
    double total = 0;
    for (var item in itens) {
      total += item.total;
    }
    return total;
  }
}

// --- BANCO DE DADOS (MEMÓRIA) ---
class BancoDeDados {
  static List<Usuario> usuarios = [
    Usuario(nome: 'admin', senha: '123456', nivel: 'Moderador'),
  ];

  static List<Comanda> comandas = [];
  static Usuario? usuarioLogado;
  static List<Categoria> categorias = [
    Categoria(nome: 'LANCHES', produtos: [
      Produto(nome: 'X-SALADA', preco: 22.00, descricao: 'Pão, hamburguer, queijo'),
      Produto(nome: 'X-BACON', preco: 25.00, descricao: 'Com muito bacon'),
    ]),
    Categoria(nome: 'BEBIDAS', produtos: [
      Produto(nome: 'COCA-COLA LATA', preco: 6.00, descricao: '350ml'),
      Produto(nome: 'SUCO NATURAL', preco: 8.50),
    ]),
    Categoria(nome: 'PORÇÕES', produtos: [
      Produto(nome: 'BATATA FRITA', preco: 18.00),
    ]),
  ];

  // --- MÉTODOS DE USUÁRIO ---
  static void adicionarUsuario(String nome, String senha, String nivel) {
    usuarios.add(Usuario(nome: nome, senha: senha, nivel: nivel));
  }

  static bool verificarLogin(String nome, String senha) {
    for (var user in usuarios) {
      if (user.nome == nome && user.senha == senha) return true;
    }
    return false;
  }

  // --- MÉTODOS DE CATEGORIA ---
  static void adicionarCategoria(String nome) {
    categorias.add(Categoria(nome: nome));
  }

  static void editarCategoria(int index, String novoNome) {
    categorias[index].nome = novoNome;
  }

  static void removerCategoria(int index) {
    categorias.removeAt(index);
  }

  // --- MÉTODOS DE PRODUTO ---
  static void adicionarProduto(int catIndex, String nome, double preco, String descricao) {
    categorias[catIndex].produtos.add(Produto(nome: nome, preco: preco, descricao: descricao));
  }

  static void editarProduto(int catIndex, int prodIndex, String nome, double preco, String descricao) {
    var p = categorias[catIndex].produtos[prodIndex];
    p.nome = nome;
    p.preco = preco;
    p.descricao = descricao;
  }

  static void removerProduto(int catIndex, int prodIndex) {
    categorias[catIndex].produtos.removeAt(prodIndex);
    categorias[catIndex].produtos.removeAt(prodIndex);
  }

  // --- MÉTODOS DE COMANDA ---
  static Comanda pegarOuAbrirComanda(int numeroMesa) {
    try {
      return comandas.firstWhere((c) => c.numeroMesa == numeroMesa && c.status == 'Aberta');
    } catch (e) {
      var novaComanda = Comanda(numeroMesa: numeroMesa);
      comandas.add(novaComanda);
      return novaComanda;
    }
  }
}